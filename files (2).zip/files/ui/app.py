# ============================================================
#  ui/app.py — Flask + SocketIO + Admin Login
# ============================================================
import os, sys, logging
from functools import wraps

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import FLASK_HOST, FLASK_PORT, FLASK_DEBUG, SECRET_KEY
from core.database import get_recent_detections, get_stats, get_snapshots, init_db
from core.ml_engine import get_model_info

from flask import Flask, render_template, jsonify, request, redirect, url_for, session
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["SECRET_KEY"] = SECRET_KEY
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading",
                    logger=False, engineio_logger=False)

logger = logging.getLogger("Dashboard")

ADMIN_USERNAME     = "admin"
ADMIN_PASSWORD_HASH = generate_password_hash("admin123")
_process_monitor   = None


def set_monitors(pm):
    global _process_monitor
    _process_monitor = pm


def broadcast_alert(alert: dict):
    """Broadcast alert to dashboard via SocketIO."""
    try:
        socketio.emit("alert", alert, namespace="/")
    except Exception as e:
        logger.error(f"Broadcast error: {e}")


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


# ── Auth ─────────────────────────────────────────────────────
@app.route("/login", methods=["GET","POST"])
def login():
    if session.get("logged_in"):
        return redirect(url_for("index"))
    error = None
    if request.method == "POST":
        u = request.form.get("username","")
        p = request.form.get("password","")
        if u == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, p):
            session["logged_in"] = True
            session["username"]  = u
            return redirect(url_for("index"))
        error = "Invalid username or password!"
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ── Pages ─────────────────────────────────────────────────────
@app.route("/")
@login_required
def index():
    return render_template("dashboard.html")


@app.route("/backend")
@login_required
def backend_panel():
    return render_template("backend.html")


# ── API ───────────────────────────────────────────────────────
@app.route("/api/stats")
@login_required
def api_stats():
    return jsonify(get_stats())


@app.route("/api/detections")
@login_required
def api_detections():
    limit = request.args.get("limit", 100, type=int)
    return jsonify(get_recent_detections(limit))


@app.route("/api/snapshots")
@login_required
def api_snapshots():
    return jsonify(get_snapshots(60))


@app.route("/api/live")
@login_required
def api_live():
    from core.process_monitor import latest_stats, stats_lock
    with stats_lock:
        return jsonify(dict(latest_stats))


@app.route("/api/model")
@login_required
def api_model():
    return jsonify(get_model_info())


@app.route("/api/kill/<int:pid>", methods=["POST"])
@login_required
def api_kill(pid):
    if _process_monitor is None:
        return jsonify({"success": False, "error": "Monitor not running"}), 503
    success = _process_monitor.kill_process(pid)
    return jsonify({"success": success, "pid": pid})


# ── SocketIO ──────────────────────────────────────────────────
@socketio.on("connect")
def on_connect():
    logger.info("Dashboard client connected.")
    emit("connected", {"message": "RansomShield connected"})


@socketio.on("disconnect")
def on_disconnect():
    logger.info("Dashboard client disconnected.")


def run_dashboard():
    init_db()
    logger.info(f"Dashboard → http://{FLASK_HOST}:{FLASK_PORT}")
    socketio.run(app, host=FLASK_HOST, port=FLASK_PORT, debug=FLASK_DEBUG,
                 allow_unsafe_werkzeug=True)