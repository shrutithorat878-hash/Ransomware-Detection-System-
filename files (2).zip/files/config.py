# ============================================================
#  config.py — Central Configuration
# ============================================================
import os

# --- Paths ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR  = os.path.join(BASE_DIR, "logs")
MODEL_DIR = os.path.join(BASE_DIR, "models")
DB_PATH  = os.path.join(DATA_DIR, "detections.db")
LOG_PATH = os.path.join(LOG_DIR, "detector.log")

# --- Directories to Monitor ---
# Windows OneDrive Desktop fix + standard paths
_home = os.path.expanduser("~")

def _find_dirs():
    candidates = [
        os.path.join(_home, "Documents"),
        os.path.join(_home, "Downloads"),
        os.path.join(_home, "Desktop"),
        os.path.join(_home, "OneDrive", "Desktop"),
        os.path.join(_home, "OneDrive", "Documents"),
        os.path.join(_home, "OneDrive - Personal", "Desktop"),
        # Project folder itself for demo
        BASE_DIR,
    ]
    return [d for d in candidates if os.path.exists(d)]

WATCH_DIRECTORIES = _find_dirs()

# --- Ransomware Known Extensions ---
RANSOMWARE_EXTENSIONS = {
    ".locked", ".enc", ".encrypted", ".crypto", ".crypt",
    ".locky", ".zepto", ".cerber", ".zzz", ".vault",
    ".petya", ".wcry", ".wncry", ".wncryt", ".sage",
    ".globe", ".dharma", ".adobe", ".java", ".STOP",
    ".djvu", ".pony", ".ransom", ".pays", ".helpme",
}

# --- Detection Thresholds ---
FILE_CHANGE_RATE_THRESHOLD = 5         # files/sec → alert (lowered for easier demo)
CPU_SPIKE_THRESHOLD        = 85.0
MEMORY_SPIKE_THRESHOLD     = 90.0
ENTROPY_THRESHOLD          = 7.2
MONITOR_INTERVAL           = 1.0

# --- Anomaly Detection ---
ANOMALY_CONTAMINATION = 0.05

# --- Flask ---
FLASK_HOST  = "127.0.0.1"
FLASK_PORT  = 5000
FLASK_DEBUG = False
SECRET_KEY  = "ransomware-detector-fyp-2024"