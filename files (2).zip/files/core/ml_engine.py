# ============================================================
#  core/ml_engine.py — Anomaly Detection (IsolationForest)
# ============================================================
import os
import sys
import logging
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import MODEL_DIR, ANOMALY_CONTAMINATION

import joblib
import psutil
from sklearn.ensemble import IsolationForest

logger = logging.getLogger("MLEngine")

MODEL_PATH = os.path.join(MODEL_DIR, "isolation_forest.pkl")

_model: IsolationForest = None


def _collect_baseline(samples=120, interval=0.5):
    """
    Collect real system stats for ~60 seconds to build a baseline.
    This captures YOUR machine's normal CPU/RAM behavior.
    """
    logger.info(f"Collecting {samples} baseline samples from your system (~{int(samples*interval)}s)...")
    data = []
    for i in range(samples):
        cpu = psutil.cpu_percent(interval=interval)
        ram = psutil.virtual_memory().percent
        # File rate starts at 0 — will be updated by real monitoring
        data.append([cpu, ram, 0.0])
        if i % 20 == 0:
            logger.info(f"  Baseline progress: {i}/{samples} (CPU:{cpu:.1f}% RAM:{ram:.1f}%)")
    return data


def _load_or_create_model():
    global _model
    os.makedirs(MODEL_DIR, exist_ok=True)

    if os.path.exists(MODEL_PATH):
        _model = joblib.load(MODEL_PATH)
        logger.info("ML model loaded from disk.")
        return

    # No model found — collect real baseline from this machine
    logger.info("No model found — collecting real baseline from your system...")
    logger.info("This takes ~60 seconds on first run only. Please wait...")

    baseline_data = _collect_baseline(samples=120, interval=0.5)
    X_train = np.array(baseline_data)

    # Add some synthetic ransomware-like samples so the model knows what's abnormal
    # High CPU + High RAM + High file rate = suspicious
    rng = np.random.default_rng(42)
    attack_samples = np.column_stack([
        rng.uniform(90, 100, 20),   # very high CPU
        rng.uniform(92, 99, 20),    # very high RAM
        rng.uniform(15, 30, 20),    # very high file rate
    ])

    # Combine: mostly normal, few attack-like for contamination reference
    X_combined = np.vstack([X_train, attack_samples])

    _model = IsolationForest(
        n_estimators=200,
        contamination=ANOMALY_CONTAMINATION,
        random_state=42
    )
    _model.fit(X_combined)
    joblib.dump(_model, MODEL_PATH)
    logger.info("Model trained on your real system baseline and saved.")


def score_anomaly(cpu: float, ram: float, file_rate: float) -> int:
    """
    Returns -1 (anomaly) or 1 (normal).
    Only flags as anomaly when MULTIPLE indicators spike together.
    """
    global _model
    if _model is None:
        _load_or_create_model()

    # Extra guard: don't flag if file_rate is 0 (no file activity = not ransomware)
    if file_rate < 1.0:
        return 1   # Normal — ransomware always causes file activity

    X = np.array([[cpu, ram, file_rate]])
    result = _model.predict(X)
    return int(result[0])


def retrain_model(samples: list):
    global _model
    if len(samples) < 50:
        logger.warning("Not enough samples to retrain (<50). Skipping.")
        return False
    X = np.array(samples)
    _model = IsolationForest(
        n_estimators=200,
        contamination=ANOMALY_CONTAMINATION,
        random_state=42
    )
    _model.fit(X)
    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(_model, MODEL_PATH)
    logger.info(f"Model retrained with {len(samples)} samples.")
    return True


def get_model_info() -> dict:
    global _model
    if _model is None:
        _load_or_create_model()
    return {
        "type": "IsolationForest",
        "n_estimators": _model.n_estimators,
        "contamination": _model.contamination,
        "model_path": MODEL_PATH,
        "model_exists": os.path.exists(MODEL_PATH),
    }
