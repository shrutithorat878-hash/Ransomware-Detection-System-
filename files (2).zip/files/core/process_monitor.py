# ============================================================
#  core/process_monitor.py — Process & System Monitor
# ============================================================
import os
import sys
import time
import logging
import threading
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import CPU_SPIKE_THRESHOLD, MEMORY_SPIKE_THRESHOLD, MONITOR_INTERVAL
from core.database import log_detection, log_snapshot

import psutil

logger = logging.getLogger("ProcessMonitor")

# Shared latest stats — read by Flask dashboard
latest_stats = {
    "cpu": 0.0,
    "ram": 0.0,
    "processes": [],
    "file_change_rate": 0.0,
    "anomaly_score": 0.0,
}
stats_lock = threading.Lock()

# Known-safe process names (extend as needed)
WHITELIST = {
    "systemd", "python", "python3", "explorer", "svchost",
    "chrome", "firefox", "code", "bash", "sh", "zsh",
}

# Suspicious process name keywords
SUSPICIOUS_KEYWORDS = [
    "encrypt", "crypt", "ransom", "locker", "cipher",
    "payload", "dropper", "inject",
]


def is_suspicious_process(proc_name: str) -> bool:
    name = proc_name.lower()
    return any(kw in name for kw in SUSPICIOUS_KEYWORDS)


class ProcessMonitor:
    """Monitors CPU, RAM, and running processes for anomalies."""

    def __init__(self, alert_callback=None):
        self.alert_callback = alert_callback
        self._running = False
        self._thread = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("Process monitor started.")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join()
        logger.info("Process monitor stopped.")

    def _loop(self):
        # Import here to avoid circular import
        from core.file_monitor import get_file_change_rate
        from core.ml_engine import score_anomaly

        while self._running:
            cpu = psutil.cpu_percent(interval=0.5)
            ram = psutil.virtual_memory().percent
            file_rate = get_file_change_rate()
            anomaly_score = score_anomaly(cpu, ram, file_rate)

            # Collect running processes
            procs = []
            for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
                try:
                    info = p.info
                    procs.append(info)
                    # Check suspicious names
                    if is_suspicious_process(info["name"] or ""):
                        msg = f"Suspicious process: {info['name']} (PID {info['pid']})"
                        logger.warning(msg)
                        log_detection(
                            threat_type="Suspicious Process",
                            severity="HIGH",
                            description=msg,
                            process_name=info["name"],
                            pid=info["pid"]
                        )
                        if self.alert_callback:
                            self.alert_callback({
                                "type": "Suspicious Process",
                                "severity": "HIGH",
                                "message": msg,
                                "time": datetime.now().isoformat()
                            })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass

            # CPU spike alert
            if cpu > CPU_SPIKE_THRESHOLD:
                msg = f"CPU spike detected: {cpu}%"
                logger.warning(msg)
                log_detection(
                    threat_type="CPU Spike",
                    severity="MEDIUM",
                    description=msg
                )
                if self.alert_callback:
                    self.alert_callback({
                        "type": "CPU Spike",
                        "severity": "MEDIUM",
                        "message": msg,
                        "time": datetime.now().isoformat()
                    })

            # RAM spike alert
            if ram > MEMORY_SPIKE_THRESHOLD:
                msg = f"Memory spike detected: {ram}%"
                logger.warning(msg)
                log_detection(
                    threat_type="Memory Spike",
                    severity="MEDIUM",
                    description=msg
                )

            # ML anomaly alert
            if anomaly_score == -1:   # IsolationForest returns -1 for anomalies
                msg = f"ML anomaly detected → CPU:{cpu}% RAM:{ram}% FileRate:{file_rate}/s"
                logger.critical(msg)
                log_detection(
                    threat_type="ML Anomaly",
                    severity="CRITICAL",
                    description=msg
                )
                if self.alert_callback:
                    self.alert_callback({
                        "type": "ML Anomaly",
                        "severity": "CRITICAL",
                        "message": msg,
                        "time": datetime.now().isoformat()
                    })

            # Update shared stats
            with stats_lock:
                latest_stats.update({
                    "cpu": cpu,
                    "ram": ram,
                    "processes": procs[:20],   # top 20
                    "file_change_rate": file_rate,
                    "anomaly_score": float(anomaly_score),
                })

            # Persist snapshot
            log_snapshot(cpu, ram, file_rate, float(anomaly_score))

            time.sleep(MONITOR_INTERVAL)

    def kill_process(self, pid: int) -> bool:
        """Forcibly terminate a process by PID."""
        try:
            p = psutil.Process(pid)
            p.terminate()
            p.wait(timeout=3)
            msg = f"Process terminated: PID {pid}"
            logger.info(msg)
            log_detection(
                threat_type="Process Killed",
                severity="INFO",
                description=msg,
                pid=pid,
                action_taken="killed"
            )
            return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.TimeoutExpired) as e:
            logger.error(f"Could not kill PID {pid}: {e}")
            return False
