# ============================================================
#  core/database.py — SQLite Storage Layer
# ============================================================
import sqlite3
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import DB_PATH, DATA_DIR
from datetime import datetime


def init_db():
    """Initialize database and create tables if they don't exist."""
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS detections (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT NOT NULL,
            threat_type TEXT NOT NULL,
            severity    TEXT NOT NULL,
            description TEXT NOT NULL,
            file_path   TEXT,
            process_name TEXT,
            pid         INTEGER,
            action_taken TEXT DEFAULT 'logged'
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS system_snapshots (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT NOT NULL,
            cpu_percent REAL,
            ram_percent REAL,
            file_change_rate REAL,
            anomaly_score REAL
        )
    """)

    conn.commit()
    conn.close()


def log_detection(threat_type, severity, description,
                  file_path=None, process_name=None, pid=None, action_taken="logged"):
    """Insert a detection event into the database."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO detections (timestamp, threat_type, severity, description,
                                file_path, process_name, pid, action_taken)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (datetime.now().isoformat(), threat_type, severity, description,
          file_path, process_name, pid, action_taken))
    conn.commit()
    conn.close()


def log_snapshot(cpu, ram, file_change_rate, anomaly_score=0.0):
    """Insert a system snapshot for trend analysis."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO system_snapshots (timestamp, cpu_percent, ram_percent,
                                      file_change_rate, anomaly_score)
        VALUES (?, ?, ?, ?, ?)
    """, (datetime.now().isoformat(), cpu, ram, file_change_rate, anomaly_score))
    conn.commit()
    conn.close()


def get_recent_detections(limit=50):
    """Fetch recent detections for the dashboard."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM detections ORDER BY id DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def get_stats():
    """Return summary statistics."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM detections")
    total = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM detections WHERE severity='CRITICAL'")
    critical = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM detections WHERE severity='HIGH'")
    high = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM detections WHERE DATE(timestamp)=DATE('now')")
    today = c.fetchone()[0]
    conn.close()
    return {"total": total, "critical": critical, "high": high, "today": today}


def get_snapshots(limit=60):
    """Return recent system snapshots for charts."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM system_snapshots ORDER BY id DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return list(reversed(rows))
