# ============================================================
#  core/file_monitor.py — File System Watcher
# ============================================================
import os
import sys
import math
import time
import hashlib
import threading
import logging
from collections import deque
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import (WATCH_DIRECTORIES, RANSOMWARE_EXTENSIONS,
                    ENTROPY_THRESHOLD, FILE_CHANGE_RATE_THRESHOLD)
from core.database import log_detection

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

logger = logging.getLogger("FileMonitor")

# --- Shared state (accessed by detection engine) ---
recent_changes = deque(maxlen=200)   # timestamps of recent file events
change_lock = threading.Lock()


def calculate_entropy(file_path):
    """Shannon entropy of a file — high entropy = likely encrypted."""
    try:
        with open(file_path, "rb") as f:
            data = f.read(65536)   # Read first 64KB only
        if not data:
            return 0.0
        freq = [0] * 256
        for byte in data:
            freq[byte] += 1
        entropy = 0.0
        length = len(data)
        for count in freq:
            if count:
                p = count / length
                entropy -= p * math.log2(p)
        return round(entropy, 4)
    except Exception:
        return 0.0


def get_file_hash(file_path):
    """MD5 hash of a file for integrity checks."""
    try:
        h = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None


def get_file_change_rate():
    """Events per second in the last 10 seconds."""
    now = time.time()
    with change_lock:
        recent = [t for t in recent_changes if now - t <= 10]
    return round(len(recent) / 10.0, 2)


class RansomwareEventHandler(FileSystemEventHandler):
    """Watchdog handler — reacts to file system events."""

    def __init__(self, alert_callback=None):
        super().__init__()
        self.alert_callback = alert_callback   # optional: notify dashboard

    def _register_change(self):
        with change_lock:
            recent_changes.append(time.time())

    def _check_extension(self, path):
        _, ext = os.path.splitext(path)
        if ext.lower() in RANSOMWARE_EXTENSIONS:
            msg = f"Suspicious extension detected: {ext} → {path}"
            logger.warning(msg)
            log_detection(
                threat_type="Suspicious Extension",
                severity="HIGH",
                description=msg,
                file_path=path
            )
            if self.alert_callback:
                self.alert_callback({
                    "type": "Suspicious Extension",
                    "severity": "HIGH",
                    "message": msg,
                    "path": path,
                    "time": datetime.now().isoformat()
                })

    def _check_entropy(self, path):
        entropy = calculate_entropy(path)
        if entropy >= ENTROPY_THRESHOLD:
            msg = f"High entropy file (score={entropy}): {path}"
            logger.warning(msg)
            log_detection(
                threat_type="High Entropy File",
                severity="HIGH",
                description=msg,
                file_path=path
            )
            if self.alert_callback:
                self.alert_callback({
                    "type": "High Entropy",
                    "severity": "HIGH",
                    "message": msg,
                    "path": path,
                    "time": datetime.now().isoformat()
                })

    def _check_rate(self):
        rate = get_file_change_rate()
        if rate >= FILE_CHANGE_RATE_THRESHOLD:
            msg = f"Mass file change detected: {rate} files/sec"
            logger.critical(msg)
            log_detection(
                threat_type="Mass File Change",
                severity="CRITICAL",
                description=msg
            )
            if self.alert_callback:
                self.alert_callback({
                    "type": "Mass File Change",
                    "severity": "CRITICAL",
                    "message": msg,
                    "time": datetime.now().isoformat()
                })

    def on_modified(self, event):
        if event.is_directory:
            return
        self._register_change()
        self._check_extension(event.src_path)
        self._check_entropy(event.src_path)
        self._check_rate()

    def on_created(self, event):
        if event.is_directory:
            return
        self._register_change()
        self._check_extension(event.src_path)
        self._check_entropy(event.src_path)
        self._check_rate()

    def on_deleted(self, event):
        if event.is_directory:
            return
        self._register_change()
        self._check_rate()


class FileMonitor:
    """Manages watchdog observer threads for all watch directories."""

    def __init__(self, alert_callback=None):
        self.alert_callback = alert_callback
        self.observer = Observer()
        self.handler = RansomwareEventHandler(alert_callback=alert_callback)

    def start(self):
        for directory in WATCH_DIRECTORIES:
            if os.path.exists(directory):
                self.observer.schedule(self.handler, directory, recursive=True)
                logger.info(f"Watching: {directory}")
            else:
                logger.warning(f"Directory not found, skipping: {directory}")
        self.observer.start()
        logger.info("File monitor started.")

    def stop(self):
        self.observer.stop()
        self.observer.join()
        logger.info("File monitor stopped.")
